<footer class="footer">
    <div class="container-fluid">
        <div class="row text-xs-center">
            <div class="col-sm-5 text-sm-left mb-0-5 mb-sm-0">
                Created By - <a class="nav-link text-black" target="new" href="https://www.fiverr.com/farjadakbar980/"> Farjad Akbar </a>  Copyright © <?php echo date("Y");?>  - All rights reserved
            </div>
            <div class="col-sm-7 text-sm-right">
                
            </div>
        </div>
    </div>
</footer>