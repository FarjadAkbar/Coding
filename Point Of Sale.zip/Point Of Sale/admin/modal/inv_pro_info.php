<?php

session_start();
require_once ('../../connection/connection.php');
$data = array();

// if(!empty($_POST['product_id']))
// {
  	// $product_id = trim($_POST['product_id']);
  	$product_id = "2";
		
//    $q="SELECT * FROM product_detail where p_id='$product_id'";          
   $q = "SELECT dp.*, p.* FROM product as p, product_detail as dp where p.product_id=dp.p_id and dp.p_id='$product_id'";

	$result = $conn->query($q);
	
	while($row = $result->fetch_assoc()) {	
	
	$data['product_sku']=$row['product_sku'];
	$data['product_quantity']=$row['product_quantity'];
	$data['product_sell_price']=$row['product_sell_price'];	
		
	}
// }
echo json_encode($data);
?>