<?php

session_start();
header('Content-type: application/json');
require_once ('../../connection/connection.php');
$response = array();

if(!empty($_POST['war_id']) && !empty($_POST['war_name']) )
{
  	$war_id      = $_POST['war_id'];
	$war_name      = strip_tags($_POST['war_name']);    
   $sql = "UPDATE warehouse SET war_name='$war_name' WHERE war_id='$war_id'";   
	
     	if ($conn->query($sql) === TRUE) {
			$response['status'] = 'successfully'; 
		} else {
			$response['status']= 'error';
		}
		   
				
		
}else{
            
		$response['status'] = 'error';
}

  


echo json_encode($response);
?>