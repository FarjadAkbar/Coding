<?php
 
session_start();
header('Content-type: application/json');
require_once ('../../connection/connection.php');
$response = array();

if(!empty($_POST['supplier_id']) && !empty($_POST['supplier_name']) && !empty($_POST['supplier_contact_name']) )
{
  	$supplier_id      = strip_tags($_POST['supplier_id']);
	$supplier_name      = strip_tags($_POST['supplier_name']);
    $supplier_contact_name     = strip_tags($_POST['supplier_contact_name']);
	$supplier_email      = strip_tags($_POST['supplier_email']);
    $supplier_phone     = strip_tags($_POST['supplier_phone']); 
	$supplier_address      = strip_tags($_POST['supplier_address']);
   $sql = "UPDATE suppliers SET supplier_name='$supplier_name',
   supplier_contact_name='$supplier_contact_name',supplier_email='$supplier_email',
   supplier_phone='$supplier_phone',supplier_address='$supplier_address' WHERE supplier_id='$supplier_id'";   
	
     	if ($conn->query($sql) === TRUE) {
			$response['status'] = 'successfully'; 
		} else {
			$response['status']= 'error';
		}
		   
				
		
}else{
            
		$response['status'] = 'error';
}

  


echo json_encode($response);
?>