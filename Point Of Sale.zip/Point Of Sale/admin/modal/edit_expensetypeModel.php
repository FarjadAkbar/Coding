<?php
 
session_start();
header('Content-type: application/json');
require_once ('../../connection/connection.php');
$response = array();

if(!empty($_POST['expense_type_id']) && !empty($_POST['expense_type_name']) )
{
  	$expense_type_id      = strip_tags($_POST['expense_type_id']);
	$expense_type_name      = strip_tags($_POST['expense_type_name']);    
   $sql = "UPDATE expense_types SET expense_type_name='$expense_type_name' WHERE expense_type_id='$expense_type_id'";   
	
     	if ($conn->query($sql) === TRUE) {
			$response['status'] = 'successfully'; 
		} else {
			$response['status']= 'error';
		}
		   
				
		
}else{
            
		$response['status'] = 'error';
}

  


echo json_encode($response);
?>