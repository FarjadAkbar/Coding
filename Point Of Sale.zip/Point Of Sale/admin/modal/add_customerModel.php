<?php
 
session_start();
header('Content-type: application/json');
require_once ('../../connection/connection.php');
$response = array();

if(!empty($_POST['cus_name']))
{
  
	$cus_name      = strip_tags($_POST['cus_name']);
    $cus_mobile     = strip_tags($_POST['cus_mobile']);
	$cus_email      = strip_tags($_POST['cus_email']); 
	$cus_address      = strip_tags($_POST['cus_address']);

    $sql = "INSERT INTO customers (cus_name, cus_mobile, cus_email, cus_address)
VALUES ('$cus_name', '$cus_mobile', '$cus_email', '$cus_address')";    
	
     	if ($conn->query($sql) === TRUE) {
			$response['status'] = 'successfully'; 
		} else {
			$response['status']= 'error';
		}
	
}else{
            
		$response['status'] = 'error';
}

  


echo json_encode($response);
?>