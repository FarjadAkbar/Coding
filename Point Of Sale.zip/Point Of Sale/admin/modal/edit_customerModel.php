<?php
 
session_start();
header('Content-type: application/json');
require_once ('../../connection/connection.php');
$response = array();

if(!empty($_POST['cus_id']) && !empty($_POST['cus_name']))
{
  	$cus_id      = strip_tags($_POST['cus_id']);
	$cus_name      = strip_tags($_POST['cus_name']);    
	$cus_email      = strip_tags($_POST['cus_email']);
    $cus_mobile     = strip_tags($_POST['cus_mobile']); 
	$cus_address      = strip_tags($_POST['cus_address']);
   $sql = "UPDATE customers SET cus_name='$cus_name',
   cus_email='$cus_email',cus_mobile='$cus_mobile',
   cus_address='$cus_address' WHERE cus_id='$cus_id'";   
	
     	if ($conn->query($sql) === TRUE) {
			$response['status'] = 'successfully'; 
		} else {
			$response['status']= 'error';
		}
		   
				
		
}else{
            
		$response['status'] = 'error';
}

  


echo json_encode($response);
?>