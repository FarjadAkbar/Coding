<?php
 
session_start();
header('Content-type: application/json');
require_once ('../../connection/connection.php');
$response = array();

if(!empty($_POST['auth_id']) && !empty($_POST['auth_username']) && !empty($_POST['full_name']) )
{
	$auth_id      = strip_tags($_POST['auth_id']);
  	$user_name      = strip_tags($_POST['auth_username']);
    $full_name     = strip_tags($_POST['full_name']);
	$auth_password     = md5(trim($_POST['password']));	
	if(empty($_POST['password'])) {    
	   $sql = "UPDATE auth SET auth_username='$user_name', full_name='$full_name' WHERE auth_id='$auth_id'";   
		
			if ($conn->query($sql) === TRUE) {
				$response['status'] = 'successfully'; 
			} else {
				$response['status']= 'error';
			}
		
	}else{		
		     
  	 $sql = "UPDATE auth SET auth_username='$user_name', full_name='$full_name',auth_password='$auth_password' WHERE auth_id='$auth_id'";   
	
     	if ($conn->query($sql) === TRUE) {
			$response['status'] = 'successfully'; 
		} else {
			$response['status']= 'error';
		}
		
	}
				
		
}else{
            
		$response['status'] = 'error';
}

  


echo json_encode($response);
?>