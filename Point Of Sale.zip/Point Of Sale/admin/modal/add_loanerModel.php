<?php
 
session_start();
header('Content-type: application/json');
require_once ('../../connection/connection.php');
$response = array();

if(!empty($_POST['loaner_name']))
{
  
	$loaner_name      = strip_tags($_POST['loaner_name']);
    $loaner_mobile     = strip_tags($_POST['loaner_mobile']);	
	$loaner_address      = strip_tags($_POST['loaner_address']);
    $sql = "INSERT INTO loan_needer (loaner_name, loaner_mobile, loaner_address)
VALUES ('$loaner_name', '$loaner_mobile', '$loaner_address')";    
	
     	if ($conn->query($sql) === TRUE) {
			$response['status'] = 'successfully'; 
		} else {
			$response['status']= 'error';
		}
		   
				
		
}else{
            
		$response['status'] = 'error';
}

  


echo json_encode($response);
?>