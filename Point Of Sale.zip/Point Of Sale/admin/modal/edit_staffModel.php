<?php
 
session_start();
header('Content-type: application/json');
require_once ('../../connection/connection.php');
$response = array();

if(!empty($_POST['auth_id']) && !empty($_POST['user_name']) && !empty($_POST['full_name']) )
{
	$auth_id      = strip_tags($_POST['auth_id']);
  	$user_name      = strip_tags($_POST['user_name']);
    $full_name     = strip_tags($_POST['full_name']);	
    $user_type_id     = strip_tags($_POST['user_type_id']); 
   $sql = "UPDATE auth SET auth_username='$user_name',
   full_name='$full_name',user_type_id='$user_type_id' WHERE auth_id='$auth_id'";   
	
     	if ($conn->query($sql) === TRUE) {
			$response['status'] = 'successfully'; 
		} else {
			$response['status']= 'error';
		}
		   
				
		
}else{
            
		$response['status'] = 'error';
}

  


echo json_encode($response);
?>