<?php
 
session_start();
header('Content-type: application/json');
require_once ('../../connection/connection.php');
$response = array();


if(isset($_POST["customer_mobile"])){
    $cus_mobile = strip_tags($_POST['customer_mobile']);

    $sql = "SELECT * FROM customers WHERE cus_mobile = '$cus_mobile'";    
    
    $result = $conn->query($sql);
    if(mysqli_num_rows($result) == 0){ 
        $response['status'] = 'successfully';
    }    
    else{
        $response['status']= 'error';
    }

    echo json_encode($response);    
}


?>