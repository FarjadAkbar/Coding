<?php
 
session_start();
header('Content-type: application/json');
require_once ('../../connection/connection.php');
$response = array();

if(!empty($_POST['loan_contract_id']) && !empty($_POST['amount_of_payment']))
{
  	$loan_contract_id      = trim($_POST['loan_contract_id']);
	$amount_of_payment      = strip_tags($_POST['amount_of_payment']); 	  
	$remarks      = strip_tags($_POST['remarks']); 
	$date_of_payment= date("Y-m-d"); 
	
   $sql = "INSERT INTO loan_payments (loan_contract_id,date_of_payment,amount_of_payment,remarks)
    VALUES ('$loan_contract_id','$date_of_payment','$amount_of_payment','$remarks')";   
	
     	if ($conn->query($sql) === TRUE) {
			
			$response['status'] = 'successfully'; 
			
		} else {
			$response['status']= 'error';
		}
		   
				
		
}else{
            
		$response['status'] = 'error';
}

  


echo json_encode($response);
?>