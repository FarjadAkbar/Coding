<?php

session_start();
header('Content-type: application/json');
require_once ('../../connection/connection.php');
$response = array();

if(!empty($_POST['vari_id']) && !empty($_POST['vari_name']) )
{
  	$var_id      = $_POST['vari_id'];
	$var_name      = strip_tags($_POST['vari_name']);    
   $sql = "UPDATE product_variation SET var_name='$var_name' WHERE var_id='$var_id'";   
	
     	if ($conn->query($sql) === TRUE) {
			$response['status'] = 'successfully'; 
		} else {
			$response['status']= 'error';
		}
		   
				
		
}else{
            
		$response['status'] = 'error';
}

  


echo json_encode($response);
?>