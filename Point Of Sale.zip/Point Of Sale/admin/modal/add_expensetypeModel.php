<?php

session_start();
header('Content-type: application/json');
require_once ('../../connection/connection.php');
$response = array();

if(!empty($_POST['expense_type_name']))
{
  
	$expense_type_name      = strip_tags($_POST['expense_type_name']);    
    $sql = "INSERT INTO expense_types (expense_type_name) VALUES ('$expense_type_name')";    
	
     	if ($conn->query($sql) === TRUE) {
			$response['status'] = 'successfully'; 
		} else {
			$response['status']= 'error';
		}
		   
				
		
}else{
            
		$response['status'] = 'error';
}

  


echo json_encode($response);
?>