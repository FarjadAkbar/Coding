<?php
 
session_start();
header('Content-type: application/json');
require_once ('../../connection/connection.php');
$response = array();

if(!empty($_POST['user_name']) && !empty($_POST['user_name']))
{
  
	$user_name      = strip_tags($_POST['user_name']);
    $full_name     = strip_tags($_POST['full_name']);
	$password      = md5(trim($_POST['password']));
    $user_type_id     = strip_tags($_POST['user_type_id']); 
	
    $sql = "INSERT INTO auth (auth_username, auth_password, full_name, user_type_id)
VALUES ('$user_name', '$password', '$full_name', '$user_type_id')";    
	
     	if ($conn->query($sql) === TRUE) {
			$response['status'] = 'successfully'; 
		} else {
			$response['status']= 'error';
		}
		   
				
		
}else{
            
		$response['status'] = 'error';
}

  


echo json_encode($response);
?>