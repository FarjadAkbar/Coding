<?php
 
session_start();
header('Content-type: application/json');
require_once ('../../connection/connection.php');
$response = array();

if(!empty($_POST['cat_id']) && !empty($_POST['cat_name']) )
{
  	$cat_id      = $_POST['cat_id'];
	$cat_name      = strip_tags($_POST['cat_name']);    
   $sql = "UPDATE categories SET cat_name='$cat_name' WHERE cat_id='$cat_id'";   
	
     	if ($conn->query($sql) === TRUE) {
			$response['status'] = 'successfully'; 
		} else {
			$response['status']= 'error';
		}
		   
				
		
}else{
            
		$response['status'] = 'error';
}

  


echo json_encode($response);
?>