<?php

session_start();
header('Content-type: application/json');
require_once ('../../connection/connection.php');
$response = array();

if(!empty($_POST['cat_name']))
{
  
	$cat_name      = strip_tags($_POST['cat_name']);    
    $sql = "INSERT INTO categories (cat_name) VALUES ('$cat_name')";    
	
     	if ($conn->query($sql) === TRUE) {
			$response['status'] = 'successfully'; 
		} else {
			$response['status']= 'error';
		}
		   
				
		
}else{
            
		$response['status'] = 'error';
}

  


echo json_encode($response);
?>