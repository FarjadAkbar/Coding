<?php
session_start();
header('Content-type: application/json');
require_once ('../../connection/connection.php');
$response = array();

if(!empty($_POST['vari_name']))
{
  
	$vari_name      = strip_tags($_POST['vari_name']);    
    $sql = "INSERT INTO product_variation (var_name) VALUES ('$vari_name')";    
	
     	if ($conn->query($sql) === TRUE) {
			$response['status'] = 'successfully'; 
		} else {
			$response['status']= 'error';
		}
		   
				
		
}else{
            
		$response['status'] = 'error';
}

  


echo json_encode($response);
?>