<?php

session_start();
header('Content-type: application/json');
require_once ('../../connection/connection.php');
$response = array();

if((!empty($_POST['inv']))) {


	$inv=strip_tags($_POST['inv']);	
	$payment_detail_date=strip_tags($_POST['payment_detail_date']);	
	$paid_amount     = strip_tags($_POST['remainingamount']);
	$due_amount     = strip_tags($_POST['due_amount']);
	//$remainingamount     = ;
	if($due_amount==0) { $payment_status=0; } else { $payment_status=1; }
	
	$update_invoice_table = "UPDATE  invoice_payment_detail  SET `paid_amount` = `paid_amount` + '$paid_amount',`due_amount` = '$due_amount', payment_detail_date='$payment_detail_date', payment_detail_status='$payment_status' where invoice_no_id='$inv'";    
	$conn->query($update_invoice_table);
 	
	$response['status'] = 'successfully';		

}else{	
		
	$response['status']= 'error';
	
	}



echo json_encode($response);
?>