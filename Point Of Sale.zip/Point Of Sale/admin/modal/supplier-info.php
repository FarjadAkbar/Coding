<?php

session_start();
require_once ('../../connection/connection.php');
include('../languages/'.$_SESSION['lang'].'/lang.'.$_SESSION['lang'].'.php');
if(!empty($_GET['supplier_id']))
{
  
	$supplierId = strip_tags($_GET['supplier_id']);        
	$q="SELECT * FROM suppliers where supplier_id='$supplierId'";	
     $result = $conn->query($q);
        if($result->num_rows > 0){ ?>
        <div class="table-responsive" data-pattern="priority-columns">
        <table class="footable-details table table-striped table-hover toggle-circle">
        <tbody> 
        <?php 
			while($row1=$result->fetch_assoc()) {	?>
			<tr>
				<th><?php echo $lang['Suppliers'];?></th>
				<td><?php echo $row1['supplier_name'];?></td>
			  </tr>
			  <tr>
				<th><?php echo $lang['ContactPerson'];?></th>
				<td><?php echo $row1['supplier_contact_name'];?></td>
			  </tr>
			  <tr>
				<th><?php echo $lang['Email'];?></th>
				<td><?php echo $row1['supplier_email'];?></td>
			  </tr>
			  <tr>
				<th><?php echo $lang['Phone'];?></th>
				<td><?php echo $row1['supplier_phone'];?></td>
			  </tr>
			  <tr>
				<th><?php echo $lang['Address'];?></th>
				<td><p><?php echo $row1['supplier_address'];?></p></td>
			  </tr>
			  
			<?php } ?>        
			</tbody>
			</table>   
			</div>
   
	<?php }else { echo "No Record found"; }
}

?>