<?php
 
session_start();
header('Content-type: application/json');
require_once ('../../connection/connection.php');
$response = array();

if(!empty($_POST['loan_amount']))
{
  
	$loaner_id      = strip_tags($_POST['loaner_id']);    
	$loan_amount      = strip_tags($_POST['loan_amount']);
	$datepicker_start_date     = strip_tags($_POST['datepicker_start_date']);	
	$datepicker_end_date     = strip_tags($_POST['datepicker_end_date']);	
	$detail     = strip_tags($_POST['detail']);	
    $sql = "INSERT INTO loan_contract (loaner_id, loan_amount, date_contract_start, date_contract_end, terms_and_conditions)
VALUES ('$loaner_id', '$loan_amount', '$datepicker_start_date', '$datepicker_end_date', '$detail')";    
	
     	if ($conn->query($sql) === TRUE) {	
			
			$last_id = $conn->insert_id;	
			 
			$sql1 = "INSERT INTO loan_payments (`loan_contract_id`, `date_of_payment`, `amount_of_payment`, `remarks`) VALUES ('$last_id', '$datepicker_start_date','0','None')"; 
			$conn->query($sql1);
			
			$response['status'] = 'successfully'; 
		} else {
			
			$response['status']= 'error';
		}
		   
				
		
}else{
            
		$response['status'] = 'error';
}

  


echo json_encode($response);
?>