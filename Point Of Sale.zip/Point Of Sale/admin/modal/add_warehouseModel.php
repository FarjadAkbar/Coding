<?php
session_start();
header('Content-type: application/json');
require_once ('../../connection/connection.php');
$response = array();

if(!empty($_POST['war_name']))
{
  
	$war_name      = strip_tags($_POST['war_name']);    
    $sql = "INSERT INTO warehouse (war_name) VALUES ('$war_name')";    
	
     	if ($conn->query($sql) === TRUE) {
			$response['status'] = 'successfully'; 
		} else {
			$response['status']= 'error';
		}
		   
				
		
}else{
            
		$response['status'] = 'error';
}

  


echo json_encode($response);
?>