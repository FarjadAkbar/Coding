$(document).ready(function() {

	$('.scroll-demo').jScrollPane();

});